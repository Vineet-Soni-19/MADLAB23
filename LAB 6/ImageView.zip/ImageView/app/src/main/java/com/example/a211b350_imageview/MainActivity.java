package com.example.a211b350_imageview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    boolean isEgg=true;
    public void change(View view){
        ImageView iv = findViewById(R.id.imageView);
        TextView tv = findViewById(R.id.textView);
        if(isEgg){
            iv.setImageResource(R.drawable.doremon);
            tv.setText("Doremon");
            isEgg=false;
        }else {
            iv.setImageResource(R.drawable.dorayaki);
            tv.setText("Loves Doracake");
            isEgg=true;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}